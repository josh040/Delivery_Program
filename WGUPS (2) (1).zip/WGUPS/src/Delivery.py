
import datetime

#A)
# Nearest Neighbor Algorithm to deliver packages
#B1)
# Initialize unshipped packages (indexed by address), trucks, time,
# current package (Initialize with package 15 because that has the earliest delivery time)
# (Initialize truck 2 with package 28), and total weight.
# Iterate through unshipped packages until there are none left
# Iterate through distances until the shortest distance is found
# if package with the shortest distance isn't in current delivery put it in current
# delivery
# else if package is package 12 force delivery of package 13 Package 13
# elese if package count is 0 return to hub add distance to hub to current package
# set time based on distance from hub
# else add distance from current package to new address and add time
# if package count is 16 add distance from package to HUB and add time
# if time is >= 9:05 am create truck 2 list
# reroute package 9 by picking it up from incorrect address and moving it to new address add distance
#B2)
# used pycharm to create application
#B4)
# this program to scale to handle more packages as long as they were included in the package file
#B5)
# the software's overall complexity is 0(n^3) and easy to maintain because it can deal wih normal package
#B6)
# strengths of the hashtable is that it can find the values for the key negatives are that it isn't perfect
#I
# two strengths of the delivery algorithm are that it is simple and efficient
# two other algorithms that could meet the requirements could be brute force and packages by groups
# brute force is different the the solution because it computes all outcomes and picks the fastest one
# Delivering packages by area is different because it delivers packages by the area they are in
#J I would try to implement a more dynamic program that would lead to me getting the packages delivered faster

# O(n^2)
def delivery_truck2(time_current):
    list_delivery = list()
    eligible = False
    cur_package = package_table.get('28')
    weight_total = distance_table[cur_package.address_key_get()]['HUB']
    # add_time() O(1)
    time_current = time_add(time_current, weight_total)
    # add_delivery() O(1)
    delivery_add(cur_package, list_delivery, time_current)
    # 9 packages in truck 2
    # O(n^2)
    while len(list_delivery) < 9:
        # O(n)
        for address, weight in distance_table[cur_package.address_key_get()].items():
            if unshipped_pkgs.get(address):
                # O(n)
                for package_id, package in unshipped_pkgs[address].items():
                    if package_id in truck2_pkgs:
                        cur_package = package
                        eligible = True
                        break
                if eligible:
                    weight_total += weight
                    # add_time() O(1)
                    time_current = time_add(time_current, weight)
                    # add_delivery() O(1)
                    delivery_add(cur_package, list_delivery, time_current)
                    eligible = False
                    break
    return weight_total + distance_table[list_delivery[-1].address_key_get()]['HUB'], list_delivery


# O(n^3)
def delivery_truck1(pkg_table, dist_table):
    global package_table, distance_table, unshipped_pkgs, pkg_count, truck2_pkgs
    package_table = pkg_table
    distance_table = dist_table
    # package_table.get_all() O(n^2)
    # packages_get() O(n)
    unshipped_pkgs = packages_get(package_table.get_all())
    truck1 = list()
    time = datetime.datetime(datetime.datetime.today().year, datetime.datetime.today().month,
                             datetime.datetime.today().day, 8)
    pkgs_delivered_truck2 = False
    eligible = False
    same_truck_packages = False
    current = package_table.get('15')
    weight_total = distance_table[current.address_key_get()]['HUB']
    # time_add() O(1)
    time = time_add(time, weight_total)
    # delivery_add() O(1)
    delivery_add(current, truck1, time)
    pkg_count = 1

    # O(n^3)
    while len(unshipped_pkgs) > 0:
        # O(n)
        for addr, weight in distance_table[current.address_key_get()].items():
            if unshipped_pkgs.get(addr):
                # O(n)
                for pack_id, package in unshipped_pkgs[addr].items():
                    if pack_id not in truck2_pkgs:
                        current = package
                        eligible = True
                        break
                if eligible:

                    if current.id_get() == '12' and same_truck_packages is False:
                        current = package_table.get('13')
                        weight_new = distance_table[truck1[-1].address_key_get()][
                            current.address_key_get()]
                        weight_total += weight_new
                        # O(1)
                        time = time_add(time, weight_new)
                        same_truck_packages = True
                    elif pkg_count == 0:
                        weight_total += distance_table[current.address_key_get()]['HUB']
                        # O(1)
                        time = time_add(time, distance_table[current.address_key_get()]['HUB'])
                    else:
                        weight_total += weight
                        # O(1)
                        time = time_add(time, weight)
                    if pkg_count == 16:
                        weight_total += distance_table[current.address_key_get()]['HUB']
                        pkg_count = 0
                        # O(1)
                        time = time_add(time, distance_table[current.address_key_get()]['HUB'])
                    if time.time() >= datetime.time(9, 5) and pkgs_delivered_truck2 is False:
                        # O(n^2)
                        weight2_total, list_truck2 = delivery_truck2(time)
                        pkgs_delivered_truck2 = True
                    # O(1)
                    delivery_add(current, truck1, time)
                    eligible = False
                    break
    current = package_table.get('9')
    weight_reroute = distance_table[truck1[-1].address_key_get()][current.address_key_get()] + \
                     distance_table[current.address_key_get()]["410 S State St,84111"]
    # add_time() O(1)
    time = time_add(time, weight_reroute)
    current.zip_set("84111")
    current.address_set("410 S State St")

    current.time_delivered_set(time)
    return weight_total + distance_table["410 S State St,84111"]['HUB'] + weight_reroute, weight2_total


# O(1)
def list_update(package):
    if len(unshipped_pkgs[package.address_key_get()]) > 1:
        package_list = unshipped_pkgs[package.address_key_get()]
        del package_list[package.id_get()]
    else:
        del unshipped_pkgs[package.address_key_get()]
# O(1)
def delivery_add(package, delivery_list, current_time):
    # update_list() O(1)
    list_update(package)
    delivery_list.append(package)

    package_table.get(package.id_get()).status_set('Delivered')
    package_table.get(package.id_get()).time_delivered_set(current_time)


# O(n)
def packages_get(package_list):
    addr_table = dict()
    # O(n)
    for package in package_list:
        if addr_table.get(package.address_key_get()):
            addr_table[package.address_key_get()].update({package.id_get(): package})
        else:
            addr_table.update({package.address_key_get(): {package.id_get(): package}})
    return addr_table
unshipped_pkgs = None
package_table = None
distance_table = None
pkg_count = 0
#Packages that are delayed or must be delivered on truck 2 start at 9:05 am
truck2_pkgs = ['3', '6', '18', '25', '28', '31', '32', '36', '38']
# O(1)
def time_add(current_time, miles):
    # 18 miles per hour is speed of trucks which means it takes 200 seconds per mile.
    elapsed_seconds = 200 * miles
    current_time = current_time + datetime.timedelta(seconds=elapsed_seconds)
    return current_time

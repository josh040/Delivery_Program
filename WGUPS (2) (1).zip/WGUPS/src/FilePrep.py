
import operator
from src.Objects.Table import HashTable
from src.Objects.Pkg import Pkg
import csv



#  O(n^2)
def fill_distance_table(distance_file_name):
    with open(distance_file_name, newline='') as csv_file:
        reader = csv.DictReader(csv_file)
        dict_distance = dict()
        #  O(n)
        for row in reader:
            #  O(n) --> sort_row()
            dict_distance.update({row['ORIGIN']: sort_row(row)})
        return dict_distance

#  O(n)
def sort_row(row):
    dict_distance = dict()
    del row['ORIGIN']
    #  O(n)
    for key, value in row.items():
        row[key] = float(value)
    #  O(n)
    for item in sorted(row.items(), key=operator.itemgetter(1)):
        dict_distance.update({item[0]: item[1]})
    return dict_distance
def tables_init(file_name_distance, file_packages):
    distance_table = fill_distance_table(file_name_distance)
    package_table = fill_package_table(file_packages)
    return distance_table, package_table
#  O(n)
def fill_package_table(file_packages):
    table_new = HashTable(100)
    lines = file_packages.readlines()
    #  O(n)
    for line in lines:
        package = Pkg(line.split(','))
        table_new.inserttable(package.id_get(), package)
    return table_new

class Pkg(object):
    #  O(1)
    def __init__(s, new_pkg):
        s.z = new_pkg[4]
        s.ddl = new_pkg[5]
        s.w = new_pkg[6]
        s.ident = new_pkg[0]
        s.adr = new_pkg[1]
        s.c = new_pkg[2]

        if new_pkg[7] == "\n":
            s.nts = "N/A"
        else:
            s.nts = new_pkg[7].rstrip()
        s.stat = 'Preparing for shipment'
        s.deliverey_time = None

    #  O(1)
    def address_key_get(s):
        return s.adr + ',' + s.z



    #  O(1)
    def address_get(s):
        return s.adr

    #  O(1)
    def zip_get(s):
        return s.z

    #  O(1)
    def address_set(s, adr):
        s.adr = adr

    #  O(1)
    def id_get(s):
        return s.ident
    #  O(1)
    def zip_set(s, zip):
        s.z = zip

    #  O(1)
    def status_get(s):
        return s.stat



    #  O(1)
    def time_delivered_get(s):
        return s.deliverey_time

    #  O(1)
    def get_notes(s):
        return s.nts
        #  O(1)

    def status_set(s, status_new):
        s.stat = status_new

        #  O(1)

    def time_delivered_set(s, time):
        s.deliverey_time = time
    #  O(1)
    def __str__(s):
        package_info = f"PACKAGE ID: {s.ident}\tADDRESS: {s.adr}, {s.c}, {s.z}\tWEIGHT: " \
                       f"{s.w}\tDEADLINE: {s.ddl}\tSTATUS: Delivered({str(s.deliverey_time)})"
        return package_info


class HashTable:
    #  O(n)
    def __init__(s, cap):
        s.size = 0
        s.hashtable = []
        s.capac = cap

        #  O(n)
        # Initializes the map with empty lists
        for I in range(cap):
            s.hashtable.append([])

    # creates unique hash key
    #  O(1)
    def get_hashtable(s, hashkey):
        hash_key = hash(hashkey) % s.capac
        return hash_key



    #  O(n^2)
    def get_all(s):
        package_list = []
        #  O(n)
        for place in s.hashtable:
            #  O(n)
            for item in place:
                package_list.append(item[1])
        return package_list

    #  O(1)
    def get_size(s):
        return s.size

    #places the value
    #  O(1)
    def inserttable(s, hashkey, v):
        place = s.get_hashtable(hashkey)
        s.hashtable[place].append([hashkey, v])
        s.size += 1

    #  O(n)
    def get(s, hashkey):
        place = s.get_hashtable(hashkey)
        if s.hashtable[place] is not None:
            place_list = s.hashtable[place]
            #  O(n)
            for INDEX, VALUE in place_list:
                if INDEX == hashkey:
                    return VALUE
        else:
            print("Not found.")
            return None
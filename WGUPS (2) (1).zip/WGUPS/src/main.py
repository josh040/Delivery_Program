#009925164 Joshua Novak
import datetime
from src.FilePrep import *
from src.Delivery import delivery_truck1


#  O(n^2)
def main():
    global package_table
    #  O(n)
    while True:
        print("Select an option:")
        print("[1] New package")
        print("[2] Look up package")
        print("[3] View all packages")
        print("[4] Look up time")
        print("[5] Exit")
        r = input("--> ")
        if r == str(1):
            new_package = package_prompt_new(package_table.get_size())
            package_table.inserttable(new_package.id_get(), new_package)
            print("Package added.\n")
        elif r == str(2):
            print(package_table.get(package_prompt_find()))
        elif r == str(3):
            #  O(n)
            #  package_table.get_all() O(n^2)
            for package in package_table.get_all():
                print(package)
            print()
        elif r == str(4):
            packages_found = False
            time = []
            print("\n**Use 24 hour format")
            #  O(1)
            for i in range(1, 3):
                hour = input(f"Enter hour {i}: ")
                minute = input(f"Enter minute {i}: ")
                print()
                time.append(datetime.time(int(hour), int(minute)))
            #  package_table.get_all() O(n^2)
            for package in package_table.get_all():
                package_time = package.time_delivered_get().time()
                if time[0] <= package_time <= time[1]:
                    packages_found = True
                    print(package)
            if packages_found is False:
                print("No packages delivered in time frame.")
            print()
        elif r == str(5):
            exit()
        else:
            print("Invalid Response")


distance_table, package_table = tables_init('../files/distance_table.csv',
                                            open('../files/packages.csv', 'r'))
#  O(n^3)
truck1_mileage, truck2_mileage = delivery_truck1(package_table, distance_table)
print(f"Mileage of Truck 1: {truck1_mileage}")
print(f"Mileage of Truck 2: {truck2_mileage}")
print(f"Total mileage: {truck1_mileage + truck2_mileage}")
print()
if __name__ == '__main__':
    main()
    #  O(1)


def package_prompt_new(count_package):
    print("\nEnter information followed by a comma.")
    print("(Address, City, State, Zip Code, Deadline, Weight, Special Notes)")
    print("** If there are no special notes type None")
    package = input("--> ")
    package = str(count_package + 1) + ', ' + package
    return package.split(', ')

    #  O(1)


def package_prompt_find():
    print("\nEnter a package id.")
    return input("> ")
